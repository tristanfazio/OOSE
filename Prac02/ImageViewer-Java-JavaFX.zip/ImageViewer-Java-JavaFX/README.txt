Image Viewer -- Java, JavaFX
============================

This is an (unfinished) Java-8-based image viewer, using the JavaFX. JavaFX is
a GUI framework that supersedes Swing, but is usually a separate package from 
the JDK itself.

For RedHat/Fedora systems, you generally need to install 
'java-1.8.0-oracle-javafx' (though you may need to add the appropriate 
repository beforehand).

JavaFX can also be obtained from the Oracle website.
