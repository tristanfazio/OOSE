import java.util.*;

/**
 * Represents an album of images.
 */
public class Album 
{
    // Insert your fields, constructors and methods here.
}
