Product Viewer -- Java, JavaFX
==============================

This is a simple JavaFX-based GUI application that shows a product listing, 
where products are arranged into groups. 
